package com.everis.springbootjpaactividades;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Equipo3ProyectoSemana2Application {

	public static void main(String[] args) {
		SpringApplication.run(Equipo3ProyectoSemana2Application.class, args);
	}

}
